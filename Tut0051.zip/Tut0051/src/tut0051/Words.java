/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tut0051;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Dell
 */
public class Words 
{
    private String word1;
    private String word2;
    
    public Words()
    {
        word1=getInput("Please enter word 1");  
        word2=getInput("Please enter word 2");
        Display();
        String combined=word1+word2;
        System.out.println("Concatenated result:\t "+combined);
        System.out.println("Sorted result:\t "+sort(combined));
        
    }
    
    private String sort(String word)
    {
        char tempArr[]=word.toCharArray();
        for(int i=0; i<tempArr.length; i++)
        {            
            for(int j=0; j<tempArr.length-(1+i);j++)
            {
                if(tempArr[j]>tempArr[j+1])
                {
                    char temp=tempArr[j];
                    tempArr[j]=tempArr[j+1];
                    tempArr[j+1]=temp;
                }
            }
        }
        return new String(tempArr);
    }
    
    
    private void Display()
    {
        DisplayWord(word1);
        DisplayWord(word2);
        
    }
    
    private void DisplayWord(String word)
    {
        System.out.println(word+" has "+word.length()+" characters and is"+(isAPalindrome(word)?"": " not")+" a palindome");
    }
    private boolean isAPalindrome(String word)
    {
        for(int index=0; index<word.length();index++)
        {    if(index>=word.length()-(index+1))
            {
                break;
            }
            if(word.charAt(index)!=word.charAt(word.length()-(index+1)))
            {
                return false;               
            }
        }
        return true;
    }
    private String getInput(String prompt)
    {
        System.out.print(prompt+":\t");
        BufferedReader dataInput=new BufferedReader(new InputStreamReader(System.in));
        String word="";
        try
        {
            word=dataInput.readLine();
        }
        catch(IOException ex)
        {
            System.out.println("There was an input Error");
        }
        return word;
    }
    
}
