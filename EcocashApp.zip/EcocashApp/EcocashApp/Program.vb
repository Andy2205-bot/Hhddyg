Imports System

Public Class Customer
    Public number As String
    Public name As String

    Public Sub New(ByVal number As String, ByVal name As String)
        Me.number = number
        Me.name = name
    End Sub
End Class

Public Class Bank
    Public balance As Double
    Public name As String
    Public statement As String

    Public Sub New(ByVal name As String, ByVal balance As Double, ByVal statement As String)
        Me.balance = balance
        Me.name = name
        Me.statement = statement
    End Sub
End Class

Module Program
    Dim owner As Customer = New Customer("0775523892", "Nigel Nyoni")
    Dim balance As Double = 2500.0
    Dim subscriber As Customer
    Dim amount As Double
    Dim customers As ArrayList = New ArrayList()
    Dim bank As Bank
    Dim banks As ArrayList = New ArrayList()

    Sub Main()
        customers.Add(New Customer("0782115130", "Franklin Ndlovu"))
        customers.Add(New Customer("0772372773", "Isabel Sibanda"))
        customers.Add(New Customer("0772656730", "Chiedza Chirape"))
        customers.Add(New Customer("0784957197", "Andile Sibanda"))
        customers.Add(owner)

        banks.Add(New Bank("STEDSUBS", 10000, $"25/03/2020 {vbTab}Salary D $10000"))
        banks.Add(New Bank("CABS", 10000, $"25/03/2020 {vbTab}Salary D $10000"))
        banks.Add(New Bank("POSB", 10000, $"25/03/2020 {vbTab}Salary D $10000"))


        Dim response As Integer
        response = Start()
        mainSelector(response)


    End Sub

    Sub MainSelector(ByVal response As Integer)

        Select Case response
            Case 0
                Console.Clear()
                Console.WriteLine("You have successfully blocked your line")
                Exit Sub
            Case 1
                SendMoneySelector(SendMoney(0))
            Case 2
                MakePaymentSelector(MakePayment())
            Case 3
                CashOutSelector(CashOut())
            Case 4
                AirtimeAndBundlesSelector(AirtimeAndBundles())
            Case 5
                EcocashDiasporaSelector(EcocashDiaspora())
            Case 6
                EcocashSaveSelector(EcocashSave())
            Case 7
                WalletServicesSelector(WalletServices())
            Case 8
                BankingServicesSelector(BankingServices())
            Case Else
                MainSelector(mainMenu())
        End Select

    End Sub


    Sub SendMoneySelector(ByVal response As Char)
        Select Case response
            Case "1"c
                SendToRegisteredSelector(0, 1)
            Case "2"c
                SendToRegisteredSelector(0, 2)
            Case "3"c
                SendToRegisteredSelector(0, 3)

            Case "4"c
                CheckWalletBalanceSelector()
            Case "*"c
                mainSelector(mainMenu())
            Case "0"c
                mainSelector(mainMenu())
            Case "n"
                SendMoneySelector(SendMoney(1))
            Case Else
                mainSelector(mainMenu())
        End Select

    End Sub

    Function SendMoney(ByVal screen As Integer) As Char
        Console.Clear()
        If screen = 0 Then
            Console.WriteLine("1. Send to registered customer")
            Console.WriteLine("2. Send to unregistered customer")
            Console.WriteLine("3. Ecoshopper purchase")
            Console.WriteLine("4. Check wallet balance")
            Console.WriteLine(" ")
            Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
            Console.WriteLine("")
            Console.WriteLine("n Next")
        Else
            Console.WriteLine("Previous Menu")
        End If
        Dim response As Char = Console.ReadLine()
        Return response
    End Function

    Sub SendToRegisteredSelector(ByVal count As Integer, ByVal registered As Integer)
        Console.Clear()
        If count = 0 Then
            subscriber = GetSubsciberNumber(SendToRegistered(0))
        End If
        If count = 0 Or count = 1 Then
            amount = GetAmount(SendToRegisteredGetAmount(registered), registered)
        End If
        If GetConfirmation(Confirmation(registered), registered) Then
            If amount > balance Then
                Console.WriteLine("You have insufficient balance to perform this transaction")
            ElseIf registered = 3 Then
                Console.WriteLine($"You have successfully paid amount RTGS$ {amount} to ecogrocery account, for beneficiary account {subscriber.number}. Txn ID:--")
                balance -= amount

            ElseIf subscriber.Equals(owner) Then
                Console.WriteLine("You cannot transfer to yourself")

            ElseIf registered = 2 And subscriber.name = "Unknown" Then
                Console.WriteLine($"You have successfully sent RTGS${amount} to {subscriber.number}. Approval code --")
            ElseIf subscriber.name = "Unknown" And registered = 1 Then
                Console.WriteLine("User not found")
            Else
                Console.WriteLine($"You have successfully sent RTGS${amount} to {subscriber.name}. Approval code --")
            End If

        Else
            Console.WriteLine("You have cancelled the transaction. Thank you.")
        End If
    End Sub
    Function GetSubsciberNumber(ByVal response As String) As Customer
        Select Case response
            Case "*"
                mainSelector(mainMenu())
            Case "0"
                SendMoneySelector(SendMoney(0))
            Case Else
                If response.Length() = 10 And response.Chars(0) = "0"c Then
                    For Each customer As Customer In customers
                        If customer.number = response Then
                            Return customer
                        End If
                    Next
                    Return New Customer(response, "Unknown")
                Else
                    GetSubsciberNumber(SendToRegistered(1))
                End If
        End Select
    End Function
    Function GetConfirmation(ByVal response As Char, ByVal registered As Integer) As Boolean
        Console.Clear()
        Select Case response
            Case "1"c
                Return True
            Case "2"c
                Return False
            Case "*"c
                mainSelector(mainMenu())
            Case "0"c
                SendToRegisteredSelector(1, registered)
            Case Else

        End Select
    End Function

    Sub ErrorMessage()
        Console.Clear()
        Console.WriteLine("Connection problem or invalid MMI code")
    End Sub

    Function Confirmation(ByVal registered As Integer) As Char
        Console.Clear()
        If Not registered = 3 Then
            Console.Write($"Sending RTGS$ {amount} to {subscriber.number}")
        End If

        If registered = 1 Then
            Console.Write($" {subscriber.name}")
        End If
        If registered = 3 Then
            Console.Write($"You are paying amount RTGS$ {amount} to ecogrocery account, for beneficiary account {subscriber.number}")

        End If
        Console.WriteLine()
        Console.WriteLine("Enter")
        Console.WriteLine("1. Confirm")
        Console.WriteLine("2. Cancel")
        Console.WriteLine("")
        Console.WriteLine("Press * for Main Menu And 0 For Previous Menu")
        Dim response As Char = Console.ReadLine()
        Return response
    End Function

    Function SendToRegistered(ByVal screen As Integer) As String
        Console.Clear()
        If screen = 0 Then
            Console.WriteLine("Enter subscriber number")
            Console.WriteLine("Press * for Main Menu And 0 For Previous Menu")
        Else
            Console.WriteLine("Please enter valid mobile number length")
        End If

        Dim response As String = Console.ReadLine()
        Return response
    End Function
    Function GetAmount(ByVal response As String, ByVal registered As Integer) As String
        Select Case response
            Case "-1"
                ErrorMessage()
            Case "*"
                mainSelector(mainMenu())
            Case "0"
                SendToRegisteredSelector(0, registered)
            Case Else
                Return CDbl(response)
        End Select
    End Function
    Function SendToRegisteredGetAmount(ByVal registered As Integer) As String
        Console.Clear()
        If registered = 1 Or registered = 2 Then
            Console.WriteLine("Enter amount")
            Console.WriteLine(" ")
            Console.WriteLine("Press * for Main Menu And 0 For Previous Menu")
        Else
            Console.WriteLine(" 1. $20 Hamper ")
            Console.WriteLine(" 2. $30 Hamper ")
            Console.WriteLine(" 3. $40 Hamper ")
            Console.WriteLine(" 4. $60 Hamper")
            Console.WriteLine(" 5. $150 Hamper")
            Console.WriteLine(" 6. $299 Hamper")
            Console.WriteLine(" ")
            Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
        End If
        Dim response As String = Console.ReadLine()
        If registered = 3 Then
            Select Case response
                Case "1"
                    response = "20"
                Case "2"
                    response = "30"
                Case "3"
                    response = "40"
                Case "4"
                    response = "60"
                Case "5"
                    response = "150"
                Case "6"
                    response = "299"
                Case Else
                    response = "-1"
            End Select
        End If

        Return response
    End Function

    'Sub SendToUnregisteredSelector()

    'End Sub
    'Function SendToUnregistered() As Integer

    'End Function

    'Sub EcoshopperPurchaseSelector()

    'End Sub
    'Function EcoshopperPurchase() As Integer

    'End Function

    ' Sub MakePaymentSelector(ByVal response As Integer)

    'End Sub

    Sub CashOutSelector(ByVal response As Char)
        Select Case response
            Case "1"c
                FromAgentSelector(FromAgent())
            Case "2"c
                FromATMSelector(FromATM())
            Case "3"c
                CheckWalletBalanceSelector()
            Case "*"c
                mainSelector(mainMenu())
            Case "0"c
                mainSelector(mainMenu())
            Case Else
                CashOutSelector(CashOut())
        End Select
    End Sub

    Function CashOut() As Char
        Console.Clear()
        Console.WriteLine("Please Select")
        Console.WriteLine("1. From Agent")
        Console.WriteLine("2. From ATM")
        Console.WriteLine("3. Check Wallet Balance")
        Console.WriteLine("Press * for Main Menu And 0 For Previous Menu")
        Dim response As Char = Console.ReadLine()
        Return response
    End Function

    Sub FromAgentSelector(ByVal response As Integer)
        Select Case response
            Case 0
        End Select

    End Sub

    ' Sub FromATMSelector(ByVal response As Integer)

    ' End Sub

    Sub CheckWalletBalanceSelector()
        Console.WriteLine($"Your Balance Is Rtgs$:{balance}")
    End Sub

    Function FromAgent() As Integer
        Console.Clear()
        Console.WriteLine("Enter Receiving Channel Member's  Agent Code")
        Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
        Dim response As Integer = Console.ReadLine()
        Return response
    End Function

    Function FromATM() As Integer
        Console.Clear()
        Console.WriteLine("Enter Receiving Channel Member's  Agent Code")
        Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
        Dim response As Integer = Console.ReadLine()
        Return response
    End Function

    Function CheckWalletBalance() As Integer

    End Function
    'Sub AirtimeAndBundlesSelector(ByVal response As Integer)

    'End Sub
    'Sub EcocashDiasporaSelector(ByVal response As Integer)

    ' End Sub

    'Sub EcocashSaveSelector(ByVal response As Integer)

    'End Sub
    'Sub WalletServicesSelector(ByVal response As Integer)

    ' End Sub

    Sub BankingServicesSelector(ByVal response As Char)
        Select Case response
            Case "1"c
                WalletBankSelector(True)
            Case "2"c
                WalletBankSelector(False)
            Case "3"c
                AccountStatementSelector()
            Case "4"c
                BalanceEnquirySelector()
            Case "*"c
                mainSelector(mainMenu())
            Case "0"c
                mainSelector(mainMenu())
            Case Else
                mainSelector(mainMenu())
        End Select
    End Sub

    Function BankingServices() As Char
        Console.Clear()
        Console.WriteLine("Please select")
        Console.WriteLine("1. Wallet to bank transfer")
        Console.WriteLine("2. Bank to wallet transfer")
        Console.WriteLine("3. Account statement")
        Console.WriteLine("4. Balalnce enquiry")
        Console.WriteLine(" ")
        Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
        Dim response As Char = Console.ReadLine()
        Return response
    End Function

    Sub WalletBankSelector(ByVal toBank As Boolean)
        amount = BankWalletGetAmount(BankWalletAmount())
        bank = GetBank()
        If GetBWConfirmation(BWConfirmation(toBank), toBank) Then
            If amount > 25000 Then
                Console.WriteLine("There seems to be some problem with the charge configuration, as the specified transaction amount does not match against any of the slab ranges")
            ElseIf toBank And amount <= balance Then
                balance -= amount
                bank.statement += $"{vbCrLf}{Today.ToShortDateString()}{vbTab} Ecocash C ${amount}"
                Console.WriteLine($"You have successfully transfered RTGS${amount} from your mMoney wallet to your bank. Transaction ID:")


            ElseIf Not toBank And amount <= bank.balance Then
                Console.WriteLine($"You have successfully transfered RTGS${amount} from your bank to your mMoney wallet. Transaction ID:")

            Else
                Console.WriteLine($"You have insufficient funds to perform this transaction")
            End If

        Else
            Console.WriteLine("Transaction is cancelled")
        End If

    End Sub

    Sub AccountStatementSelector()
        Console.Clear()
        bank = GetBank()
        Console.Clear()
        Console.WriteLine("-STATEMENT GOES HERE- ")
        Console.WriteLine(bank.statement)
    End Sub
    Sub BalanceEnquirySelector()
        Console.Clear()
        bank = GetBank()
        Console.Clear()
        Console.WriteLine($"Your current balance is {bank.balance}")

    End Sub

    Function BankWalletAmount() As String
        Console.Clear()
        Console.WriteLine("Enter Amount")
        Console.WriteLine("")
        Console.WriteLine("Press * for Main Menu and 0 For Previous Menu")
        Dim response As String = Console.ReadLine()
        Return response
    End Function

    Function BankWalletGetAmount(ByVal response As String) As Double
        Select Case response
            Case "-1"
                ErrorMessage()
            Case "*"
                mainSelector(mainMenu())
            Case "0"
                BankingServicesSelector(BankingServices())
            Case Else
                Return CDbl(response)
        End Select
    End Function

    Function GetBank() As Bank
        Console.Clear()
        Console.WriteLine("Select Bank Account:")
        Console.WriteLine("1. STEDSUBS")
        Console.WriteLine("2. CABS")
        Console.WriteLine("3. POSB")
        Dim response As Integer = Console.ReadLine()
        Return banks(response - 1)
    End Function
    Function GetBWConfirmation(ByVal response As Char, ByVal toBank As Boolean) As Boolean
        Console.Clear()
        Select Case response
            Case "1"c
                Return True
            Case "2"c
                Return False
            Case "*"c
                mainSelector(mainMenu())
            Case "0"c
                WalletBankSelector(toBank)
            Case Else

        End Select
    End Function



    Function BWConfirmation(ByVal toBank As Boolean) As Char
        Console.Clear()
        If toBank Then
            Console.WriteLine($"Fund transfer RTGS${amount} From your mMoney wallet to your bank-{bank.name}")

        Else
            Console.WriteLine($"Fund transfer RTGS${amount} From your bank-{bank.name} to your mMoney wallet")

        End If

        Console.WriteLine("Enter")
        Console.WriteLine("1. Confirm")
        Console.WriteLine("2. Cancel")
        Console.WriteLine("")
        Console.WriteLine("Press * for Main Menu And 0 For Previous Menu")
        Dim response As Char = Console.ReadLine()
        Return response
    End Function

    Function MakePayment() As Integer

    End Function



    Function AirtimeAndBundles() As Integer

    End Function
    Function EcocashDiaspora() As Integer

    End Function

    Function EcocashSave() As Integer

    End Function
    Function WalletServices() As Integer

    End Function




    Function Start() As Integer
        Dim count As Integer
        While count < 3
            Console.Clear()
            If Welcome(count) Then
                Return mainMenu()
            End If
            count += 1
        End While
        Return 0
    End Function

    Function Welcome(ByVal count As Integer) As Boolean
        If count > 0 Then
            Console.WriteLine("MPIN is entered incorrectly")
            Console.WriteLine("Please re-enter your PIN to start")
        Else
            Console.WriteLine("welcome to Ecocash")
            Console.WriteLine("Please enter your PIN to start")
        End If

        Dim PIN As String = Console.ReadLine()

        Return checkPiN(PIN)
    End Function

    Function CheckPiN(ByVal PIN As Integer) As Boolean
        If PIN = "1234" Then
            Return True
        End If
        Return False
    End Function

    Function MainMenu() As Integer
        Console.Clear()
        Console.WriteLine("1. Send Money")
        Console.WriteLine("2. Make Payment")
        Console.WriteLine("3. Cash Out")
        Console.WriteLine("4. Airtime and Bundles")
        Console.WriteLine("5. Ecocash Diaspora")
        Console.WriteLine("6. Ecocash Save")
        Console.WriteLine("7. Wallet Services")
        Console.WriteLine("8. Banking Services")
        Dim response As Integer = Console.ReadLine()
        Return response
    End Function


End Module
